import React from 'react';
import { Component } from 'react';
import { BrowserRouter,Route,Switch } from 'react-router-dom';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Forgot from './components/forgot';
import Header from './components/Header';
import Converter from './components/Converter';
import Login from './components/Login';
import Register from './components/Register'; 
import Reset from './components/Reset';



export default class App extends Component {

  state= {}

  // componentDidMount = () =>{
  //   // localStorage.clear();
  //   // this.setState({user: JSON.parse(localStorage.loggedInUser)});
  //   // console.log(JSON.parse(localStorage.loggedInUser));
  // }
  componentDidUpdate = () => {

    this.setState({user: JSON.parse(localStorage.loggedInUser)});
    console.log(JSON.parse(localStorage.loggedInUser));
  }

  render(){
    
  return (
    <BrowserRouter>
      <div className="App">
        <Header/>
          <div className="auth-wrapper">
            <div className="auth-inner">
              <Switch>
                  <Route exact path = "/" component={Login} />
                  <Route exact path = "/home" component = {()=><Converter user = {this.state.user} />} />
                  <Route exact path = "/register" component={Register} />
                  <Route exact path = "/forgot_password" component={Forgot} />
                  <Route exact path = "/reset_password/:id" component={Reset} />
                  {/* <Route  path = "/not-found" component={NotFound} /> */}
                  {/* <Redirect to = "not-found"/> */}
              </Switch>
            </div>
          </div>
      </div>
    </BrowserRouter>
  );
  }
}
