
import React,{Component} from "react";
import { Redirect } from "react-router-dom";

let userList = [];

export default class Register extends Component{

    buttonStyle = {
        marginLeft: '140px',
        marginTop: '20px'
    }

    fieldStyle = {
        marginTop: '20px'
    }

    state = {
        isRegistered: false
    }
    
    registrationSuccessful = ()=>{
        const{history} = this.props

        history.replace('/')
    }

    handleSubmit = e => {
        e.preventDefault();
        const data = {
            userId: userList.length,
            first_name: this.firstName,
            last_name: this.lastName,
            email:this.email,
            password:this.password,
            password_confirm: this.confirmPassword
        };

        if(data.password !== data.password_confirm){
            alert('Passwords do not match.');
            this.state.isRegistered = false;
        }
        else{
            if(userList.length > 0){
                userList.forEach((user)=>{
                    if(user.email === data.email){
                        alert('This mail id already exists.')
                    }else{
                        userList.push(data);
                        localStorage.setItem('data',JSON.stringify(userList));
                        console.log(JSON.parse(localStorage.data));
                        this.state.isRegistered = true;
                        this.render();
                        this.registrationSuccessful()
                    }
                })
            }else{
                userList.push(data);
                localStorage.setItem('data',JSON.stringify(userList));
                console.log(JSON.parse(localStorage.data));
                this.state.isRegistered = true;
                this.render();
            }
        }
    };

    render(){

         if(this.state.isRegistered){
            return <Redirect to={'/'} ></Redirect>
        }
        else{
        return(
            <form onSubmit={this.handleSubmit}>
                <h3>Sign up</h3>


                <div style={this.fieldStyle}>
                    <input type="text" className="form-control" required = "true" placeholder="First Name" 
                         onChange={e => this.firstName = e.target.value}/>
                </div>

                <div style={this.fieldStyle}>
                    <input type="text" className="form-control" required = "true" placeholder="Last Name" 
                         onChange={e => this.lastName = e.target.value}/>
                </div>

                <div style={this.fieldStyle}>
                    <input type="email" className="form-control" required = "true" placeholder="Email" 
                         onChange={e => this.email = e.target.value}/>
                </div>

                <div style={this.fieldStyle}>
                    <input type="password" className="form-control" required = "true" placeholder="Password" 
                         onChange={e => this.password = e.target.value}/>
                </div>

                <div style={this.fieldStyle}>
                    <input type="password" className="form-control" required = "true" placeholder="Confirm Password" 
                         onChange={e => this.confirmPassword = e.target.value}/>
                </div>
                <div style={this.buttonStyle}>
                <button className="btn btn-primary btn-block">
                    Sign Up
                </button>
                </div>
            </form>
        )
    }
}
}