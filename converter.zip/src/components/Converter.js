import axios from 'axios';
import React,{ useEffect, useState } from 'react';
import {
  Button,FormControl,Select,TextField
} from '@material-ui/core'
import {Link} from 'react-router-dom'



const Converter = () =>{
  const [text1,settext1]= useState(1);
  const [text2,settext2]= useState();
  const [country,setcountry] = useState([]);
  const [country2,setcountry2] = useState([]);
  const [value1,setvalue1] = useState(1);
  const [value2,setvalue2] = useState(1);

  useEffect(()=>{
    getData();
  },[])
  
  async function getData(){
    const result = await axios.get("http://data.fixer.io/api/latest?access_key=f0c81a82b76f731577ea57ed40a494ca");
    console.log(result.data);
    setcountry(result.data.rates);
    setcountry2(result.data.rates);
  }

  function convert(e){
    e.preventDefault();
    let num = (value2/value1)*text1;
    settext2(num);
  }

  return(
    <div >
      <form onSubmit={convert} style={{height:300,padding:30}}>
        <div style={{marginBottom:40}}>
          <TextField varient="outlined" onChange={(e)=>settext1(e.target.value)} autoComplete='off' value={text1 || ""}></TextField>
          <FormControl onChange={(e)=>setvalue1(e.target.value)} className="dropdown" varient = "outlined">
            <Select native>
              {Object.keys(country).map((value, index)=>
              <option key ={index} value={country[value]}>{value}</option>)}
            </Select>
          </FormControl>
        </div>

        <div style={{marginBottom:40}}>
            <TextField varient="outlined"  value={text2 || ""}></TextField>
            <FormControl onChange={(e)=>setvalue2(e.target.value)} className="dropdown" varient = "outlined">
              <Select native>
              {Object.keys(country2).map((value, index)=>
              <option key ={index} value={country[value]}>{value}</option>)}
              </Select>
            </FormControl>
        </div>
        <Button type="submit"  style={{borderStyle:'solid',backgroundColor:'blue',color:'white'}} varient="contained">
          Convert
        </Button>
      </form>
          <p className="nav-item">
                <Link to={'/'}  className="nav-link">Logout</Link>
          </p>
    </div>
  )
}

export default Converter