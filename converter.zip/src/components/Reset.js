import React,{Component} from "react";
// import { Link } from "react-router-dom";

export default class Reset extends Component{

    buttonStyle = {
        marginLeft: '110px',
        marginTop: '20px'
    }

    fieldStyle = {
        marginTop: '20px'
    }
    
    passwordResetted=()=>{
        const{history} = this.props 
        history.replace('/')
    }

    resetPassword = e => {
        e.preventDefault();

        const data = {
            id: this.props.match.params.id,
            password: this.password,
            confirm_password: this.confirm_password,
        }

        console.log(data);
        let userList = [];
        const users = localStorage.getItem('data');
        userList = JSON.parse(users);
        console.log(userList);

        userList.forEach((user)=>{
            if(user.userId == data.id){
                if(data.password === data.confirm_password){
                    user.password = data.password;
                    user.password_confirm = data.confirm_password;
                    localStorage.setItem('data',JSON.stringify(userList));  
                    this.passwordResetted();
                    alert("Password Resetted")
                             
                }else{
                    alert('Passwords does not match.')
                }
            }
        })

    };

    render(){
        return(
            <form onSubmit={this.resetPassword}>
                <h3>Reset</h3>
   
                <div style={this.fieldStyle}>
                    <input type="password" className="form-control" placeholder="Password" 
                         onChange={e => this.password = e.target.value}/>
                </div>

                <div style={this.fieldStyle}>
                    <input type="password" className="form-control" placeholder="Confirm Password" 
                         onChange={e => this.confirm_password = e.target.value}/>
                </div>

                <div style={this.buttonStyle}>
                    <button className="btn btn-primary btn-block">
                        Reset Password
                    </button>
                </div>
            </form>
        )
    }
}