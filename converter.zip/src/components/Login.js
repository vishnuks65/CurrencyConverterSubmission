import React,{Component} from "react";
import { Link,Redirect} from "react-router-dom";

export default class Login extends Component{

    buttonStyle = {
        marginLeft: '140px',
        marginTop: '20px'
    }

    fieldStyle = {
        marginTop: '20px'
    }
    
   loggedin =()=>{
        const {history} = this.props 
        history.replace('/home')
   }

    handleSubmit = e => {
        e.preventDefault();

        const data = {
            email: this.email,
            password: this.password,
        }

        console.log(data);
        let userList = [];
        const users = localStorage.getItem('data');
        if(users!==null){
          userList = JSON.parse(users);
        }
        console.log(userList);

        let flag = true;
        
        userList.forEach((user)=>{
            if(user.email === data.email){
                if(user.password === data.password){
                    localStorage.setItem('loggedInUser',JSON.stringify(user));
                    alert('Welcome '+user.first_name);
                    this.loggedin(user)
                }else{
                    alert('Please enter correct password');
                }
            flag = false;
            }
        })

        if(flag){
            alert('Username not found. Please Signup.');
        }
    
    };

    render(){
        return(
            <form onSubmit={this.handleSubmit}>
                <h3>Login</h3>     
                <div style={this.fieldStyle}>
                    <input type="email" className="form-control" placeholder="Email" 
                         onChange={e => this.email = e.target.value}/>
                </div>

                <div style={this.fieldStyle}>
                    <input type="password" className="form-control" placeholder="Password" 
                         onChange={e => this.password = e.target.value}/>
                </div>

                <div style={this.buttonStyle}>
                <button className="btn btn-primary btn-block">
                    Login
                </button>
                </div>

                <p className="forgot-password text-right">
                    <Link to={'/forgot_password'}>Forgot Password?</Link>
                    </p>
            </form>
        )
    }
}