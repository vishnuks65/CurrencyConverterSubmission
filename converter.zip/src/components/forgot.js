import emailjs from "emailjs-com";
import React,{Component} from "react";

export default class Forgot extends Component{

    buttonStyle = {
        marginLeft: '140px',
        marginTop: '20px'
    }

    sendEmail = e => {

        e.preventDefault();
        
        let userList = [];
        const users = localStorage.getItem('data');
        userList = JSON.parse(users);
        let firstName='';
        let userID = -1;

        userList.forEach((user)=>{
            if(user.email === this.email){
                firstName = user.first_name;
                userID = user.userId;
            }
        })

        const data = {
            email: this.email,
            userId: userID,
            first_name: firstName
        }

        //contains parameter info of my emailjs account
        emailjs.send(
            "service_ab59mxq",
            "template_0plg2sr",
            data,
            "user_kCJcyeiO8lhQvhhOgpvbc").then(res=>{
                console.log(res);
                alert("Please check your email for reset link")
            }).catch(err=>{
                console.log(err);
                alert("Something went wrong")
            })

    }

    
    render(){
        return(
            <form onSubmit={this.sendEmail}>
                <h3>Forgot Password</h3>
                
                <div className="form-group">
                    <input type="email" className="form-control" placeholder="Email" 
                         onChange={e => this.email = e.target.value}/>
                </div>

                <div style={this.buttonStyle}>
                    <button className="btn btn-primary btn-block">
                        Submit
                    </button>
                </div>
            </form>
        )
    }
}